<?php

class UsuarioDAO
{
    private PDO $pdo;

    // constructor existente: public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    public function buscarPorEmail(string $email): ?Usuario
    {
        $sql = "SELECT id, nombre, email, edad
                FROM usuarios
                WHERE email = :email
                LIMIT 1";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':email' => $email]);

        $fila = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($fila === false) {
            return null;
        }

        return new Usuario(
            (int) $fila['id'],
            $fila['nombre'],
            $fila['email'],
            (int) $fila['edad']
        );
    }
}
