<?php

class Usuario
{
    private ?int $id;
    private string $nombre;
    private string $email;
    private int $edad;

    // constructor y getters existentes...

    public function cambiarEmail(string $nuevoEmail): void
    {
        $nuevoEmail = trim($nuevoEmail);

        if (!filter_var($nuevoEmail, FILTER_VALIDATE_EMAIL)) {
            throw new InvalidArgumentException("Formato de correo no válido.");
        }

        $this->email = $nuevoEmail;
    }
}
