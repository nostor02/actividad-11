# Examen: Entidad, DAO, Repository y Service (PHP)

> Nota: se asume que la clase `Usuario` tiene los atributos `id`, `nombre`, `email` y `edad`, con constructor y `getNombre()`, y que `UsuarioDAO` recibe un `PDO` en `$this->pdo` y trabaja sobre la tabla `usuarios`.

---

## Parte A. Clasificación

| # | Responsabilidad | Clase y justificación |
|---|---|---|
| 1 | Evitar nombres vacíos | **Entidad.** Es una regla sobre el propio atributo `nombre`, así que debe validarse dentro de la entidad. |
| 2 | Consultar usuarios por correo en MySQL | **DAO.** Ejecuta una consulta SQL contra la base de datos. |
| 3 | Calcular si el usuario es mayor de edad | **Entidad.** Es un comportamiento que usa solo los datos del usuario (`edad`) y no necesita acceder a la base de datos. |
| 4 | Actualizar la edad almacenada en la tabla | **DAO.** Ejecuta un `UPDATE` sobre la tabla. |
| 5 | Mostrar una alerta en el navegador | **Otra clase (Controlador o vista).** Es presentación e interacción con el usuario, no lógica de datos ni de negocio. |
| 6 | Convertir resultados SQL en objetos Usuario | **DAO.** Es el mapeo de filas de la base de datos a objetos, y el DAO es quien conoce el formato de esas filas. |
| 7 | Rechazar una edad negativa | **Entidad.** Es una validación de un atributo propio, que debe impedir que el objeto quede en un estado inválido. |
| 8 | Responder con HTTP 404 si no existe el usuario | **Otra clase (Controlador).** Traduce el resultado de la operación en una respuesta HTTP. |

---

## Parte B. Implementación

### 1. Método `cambiarEmail` en `Usuario`

```php
<?php
class Usuario
{
    private ?int $id;
    private string $nombre;
    private string $email;
    private int $edad;

    // constructor y getters existentes...

    public function cambiarEmail(string $nuevoEmail): void
    {
        $nuevoEmail = trim($nuevoEmail);

        if (!filter_var($nuevoEmail, FILTER_VALIDATE_EMAIL)) {
            throw new InvalidArgumentException("Formato de correo no válido.");
        }

        $this->email = $nuevoEmail;
    }
}
```

### 2. Método `buscarPorEmail` en `UsuarioDAO`

```php
<?php
class UsuarioDAO
{
    private PDO $pdo;

    // constructor existente: public function __construct(PDO $pdo) { $this->pdo = $pdo; }

    public function buscarPorEmail(string $email): ?Usuario
    {
        $sql = "SELECT id, nombre, email, edad
                FROM usuarios
                WHERE email = :email
                LIMIT 1";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':email' => $email]);

        $fila = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($fila === false) {
            return null;
        }

        return new Usuario(
            (int) $fila['id'],
            $fila['nombre'],
            $fila['email'],
            (int) $fila['edad']
        );
    }
}
```

### 3. ¿Por qué `cambiarEmail()` no debe ejecutar un `UPDATE` directamente?

- **Separación de responsabilidades.** En el nuevo modelo, la entidad "no accede directamente a la base de datos". Si `Usuario` ejecutara SQL, tendría que conocer la conexión y la tabla, y dejaría de ser un objeto de dominio simple.
- **Persistencia en un solo lugar.** Cuando el cambio pasa por el DAO o el Repository, la forma de guardar queda centralizada. Si cambia la base de datos, solo se modifica esa capa.
- **Estado coherente.** `cambiarEmail()` valida y actualiza el objeto en memoria. Guardar el cambio es una decisión posterior, que el Service coordina, por ejemplo verificando que el correo nuevo no esté ya en uso por otro usuario.
- **Pruebas más simples.** Sin base de datos, la validación del correo se puede probar con un objeto `Usuario` solo en memoria.

### 4. Ejemplo de uso

```php
<?php
$pdo = new PDO('mysql:host=localhost;dbname=tienda;charset=utf8mb4', 'usuario', 'clave', [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
]);

$dao = new UsuarioDAO($pdo);

$usuario = $dao->buscarPorEmail('ana@correo.com');

if ($usuario !== null) {
    echo "Usuario encontrado: " . $usuario->getNombre();
} else {
    echo "No existe un usuario con ese correo.";
}
```

---

**Entrega:** tabla resuelta, código de los dos métodos y explicación de las decisiones.
